package edu.cgcc.cs260;


public class userAlerts {

    try


     } catch {
        {
public void renameFailed () {
        System.out.println("Invalid name, please enter a valid name");
        }
public void;

    }


}

