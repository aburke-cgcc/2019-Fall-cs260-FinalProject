package edu.cgcc.cs260;

public class printOptions {
    public static void printMenu() {
        System.out.println("Available actions: \npress");
        System.out.println("1 to Play Playlist \n" +
                "2 - Stop Song" +
                "3 - Delete Song" +
                "4 - Skip Forward" +
                "5 - Skip Backward" +
                "6 - Quit Playlist");
    }
}
